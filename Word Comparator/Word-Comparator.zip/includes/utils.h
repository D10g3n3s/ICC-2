#ifndef UTILS_H
    #define UTILS_H

    #include <boolean.h>

    char* readLine(FILE *input);
    char* readWord(FILE *input);

#endif