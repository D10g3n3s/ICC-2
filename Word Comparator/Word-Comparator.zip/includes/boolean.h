#ifndef BOOLEAN_H
    #define BOOLEAN_H

    #define bool int 
    #define TRUE 1
    #define FALSE 0
#endif